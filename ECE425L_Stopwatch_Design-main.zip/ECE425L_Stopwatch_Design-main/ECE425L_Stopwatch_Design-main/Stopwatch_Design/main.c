/*
 * @file main.c
 *
 * @brief Main source code for the Stopwatch_Design program.
 *
 * This file contains the main entry point and function definitions for the Stopwatch_Design program.
 * This lab involves designing a basic stopwatch. It demonstrates edge-triggered interrupts, 
 * and it interfaces with the following:
 *  - User LED (RGB) Tiva C Series TM4C123G LaunchPad
 *	- EduBase Board LEDs (LED0 - LED3)
 *	- EduBase Board Push Buttons (SW2 - SW3)
 *	- EduBase Board Seven-Segment Display
 *	- PMOD BTN module
 *
 * It configures the pins used by the EduBase Board push buttons (SW2 and SW3) and the PMOD
 * BTN module to generate interrupts on rising edges.
 * 
 * Timer 0A is used to generate periodic interrupts every 1 millisecond. The values of the 
 * stopwatch (milliseconds, seconds, and minutes) will increment in the Timer 0A
 * periodic task. The PMOD BTN module will be used to control the stopwatch.
 *
 * @Eric Aivazian
 */

#include "TM4C123GH6PM.h"
#include "GPIO.h"
#include "PMOD_BTN_Interrupt.h"
#include "EduBase_Button_Interrupt.h"
#include "Seven_Segment_Display.h"
#include "Timer_0A_Interrupt.h"

//declare the user-defined function prototype for PMOD_BTN_Interrupt
void PMOD_BTN_Handler(uint8_t pmod_btn_status);

//declare the user-defined function prototype for EduBase_Button_Interrupt
void EduBase_Button_Handler(uint8_t edubase_button_status);

//initialize a global variable for an 8-bit counter
static uint8_t counter = 0;

// Declare the function prototype for the function that calculates
// stopwatch value and stores it in an array
void Calculate_Stopwatch_Value (uint8_t stopwatch_value[]);

// Declare the function prototype for the user-defined function for Timer 0A
void Timer_0A_Periodic_Task(void);

// Initialize a global variable for Timer 0A to keep track of elapsed time in milliseconds
static uint8_t ms_elapsed = 0;

// Initialize global variables to keep track of the stopwatch value (i.e. milliseconds, seconds, and minutes) 
// "milliseconds" is updated every 100 ms (Range: 0 to 999 ms)
// "seconds" is updated every 1000 ms (Range: 0 to 59 s)
// "minutes" is updated every 60 seconds (Range: 0 to 9 minutes) 
static uint8_t milliseconds = 0;
static uint8_t seconds = 0;
static uint8_t minutes = 0;

// Initialize global flags for starting and resetting the stopwatch 
static uint8_t start_stopwatch = 0;
static uint8_t reset_stopwatch = 0;

int main(void)
{
	// initialize the SysTick timer used to provide blocking delay functions
	SysTick_Delay_Init();
	
	//Initialize the push buttons on the PMOD BTN module (Port A)
	PMOD_BTN_Interrupt_Init(&PMOD_BTN_Handler);
	
	//Initialize the LEDs on the EduBase board (port B)
	EduBase_LEDs_Init();
	
	// initialize the seven segment display
	Seven_Segment_Display_Init();
	
	// initialize the SW2 and S@3 on the EduBase board with interrupts enabled (port D)
	EduBase_Button_Interrupt_Init(&EduBase_Button_Handler);
	
	// Initialize the RGB LED (Port F)
	RGB_LED_Init();
	
	// Initilize Timer 0A to generate periodic interrupts every 1 ms
	Timer_0A_Interrupt_Init(&Timer_0A_Periodic_Task);
	
	// Initialize a uint8_t array to store each digit of the stopwatch value
	uint8_t stopwatch_value[4] = {0};
	
	while(1)
	{
		Calculate_Stopwatch_Value(stopwatch_value);
		Seven_Segment_Display_Stopwatch(stopwatch_value);
	}
}

/**
 * @brief
 * 
 * @param
 * 
 * @return
 */
void PMOD_BTN_Handler(uint8_t pmod_btn_status)
{
	switch(pmod_btn_status)
	{
		// BTN0 (PA2) is pressed
		case 0x04: 
		{
			RGB_LED_Output(RGB_LED_GREEN);
			start_stopwatch = 0x01;
			break;
		}
		
		// BTN1 (PA3) is pressed
		case 0x08:
		{
			RGB_LED_Output(RGB_LED_RED);
			start_stopwatch = 0x00;
			break;
		}
		
		// BTN2 (PA4) is pressed
		case 0x10:
		{
			RGB_LED_Output(RGB_LED_OFF);
			reset_stopwatch = 0x01;
			break;
		}
		
		//BTN3 (PA5) is pressed
		case 0x20:
		{
			break;
		}
		
		default:
		{
			break;
		}
	}
}




/**
 * @brief The EduBase_Button_Handler function was used in part B of the lab. It is used to increment and decrement 
 * the counter by 1 when SW5 and SW4 is pressed. 
 * 
 * @param uint8_t edubase_button_status 
 * 
 * @return none
 */

void EduBase_Button_Handler(uint8_t edubase_button_status)
{
	switch(edubase_button_status)
	{
		//when SW5 is pressed 
		case 0x08:	
		{
			if (counter >= 15)
			{
				counter = 0;
			}
			else 
			{
				counter = counter + 1;
			}
			break;
		}
		
		//when SW4 is pressed 
		case 0x04:
		{
			if (counter <= 0)
			{
				counter = 15;
			}
			else
			{
				counter = counter - 1;
			}
			break;
		}
		
		default:
		{
			break;
		}
	}
}




/**
 * @brief this function calculates the stopwatch values for milliseconds, seconds, and minutes. 
 * the values for milliseconds, seconds, and minutes are stored in the stopwatch_value array 
 * the array has 4 elements, 1 for milliseconds, two for seconds, and one for minutes. the milliseconds 
 * value is stored in element 0, seconds are stored in elements 1 and 2, and minutes are stored in element 3. 
 * 
 * @param uint8_t stopwatch_value[]
 *
 * @return none
 */
void Calculate_Stopwatch_Value(uint8_t stopwatch_value[])
{
	// Srote the "milliseconds" value in the first index of the array
	stopwatch_value[0] = milliseconds;
	
	// Store the least significant digit of the "seconds" value
	// in the second index of the array
	stopwatch_value[1] = seconds % 10;
	
	// Store the most significant digit of the "seconds" value
	// in the third index of the array
	stopwatch_value[2] = seconds / 10;
	
	// Store the "minutes" value in the fourth index of the array
	stopwatch_value[3] = minutes;
}




/**
 * @brief This function implements a stopwatch. If the start_stopwatch flag is 0x01, then the timer starts and the ms_elapsed 
 * variable is incremented. If ms_elapsed reaches 99, ms_elapsed is reset to 0, and milliseconds is incremented. If milliseconds
 * reaches 9, then milliseconds is reset to 0 and seconds is incremented. If seconds reaches 59, then seconds is reset 
 * to 0 and minutes is incremented. If minutes reaches 9, then minutes is reset to 0 and timer starts from 0. This is a 10 minute timer. 
 * 
 * @param none
 *
 * @return none
 */

void Timer_0A_Periodic_Task(void)
{
	if (start_stopwatch == 0x01)
	{
		ms_elapsed++;
		
		if (ms_elapsed > 99) 
		{
			ms_elapsed = 0;
			milliseconds++;
		}
		
		if (milliseconds > 9)
		{
			milliseconds = 0; 
			seconds++;
		}
		
		if (seconds > 59)
		{
			seconds = 0;
			minutes++;
		}
		if (minutes >9)
		{
			minutes = 0;
		}
	}
	
	if (reset_stopwatch == 1) 
	{
		reset_stopwatch = 0;
		start_stopwatch = 0;
		ms_elapsed = 0;
		milliseconds = 0;
		seconds = 0;
		minutes = 0;
	}
	
}